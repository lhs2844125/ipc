#ifndef _LED_H_
#define _LED_H_
#include "stm32f4xx.h"

void _led_init();
void _led_on();
void _led_off();

#endif//_led_h_