#include "stm32f4xx.h"

void delay_us(uint32_t nus);
void delay_ms(uint16_t nms);